$("#success-alert").fadeTo(2000, 500).slideUp(500, function(){
    $("#success-alert").slideUp(500);
});
$("#danger-alert").fadeTo(2000, 500).slideUp(500, function (){
    $("#danger-alert").slideUp(500);
});
