import '../styles/page.css';



import '../bootstrap';
import './navbar';
import './cookies';