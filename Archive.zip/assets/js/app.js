
// any CSS you import will output into a single css file (app.css in this case)
import '../styles/app.css';

import AOS from 'aos';

AOS.init();





// start the Stimulus application
import '../bootstrap';
import './navbar';
import './cookies';
