let navbar = document.querySelector('.navbar-nav')

document.querySelector('#navbar').onclick = ()=>{
     navbar.classList.toggle('active');
}