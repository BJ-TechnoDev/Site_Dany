import 'gsap';
import 'jquery';

import './homepage';

import '../styles/homepage.css';

import './alert';

